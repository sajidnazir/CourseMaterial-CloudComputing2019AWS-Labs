#https://boto3.amazonaws.com/v1/documentation/api/latest/guide/dynamodb.html

import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')

# Create the DynamoDB table.
table = dynamodb.create_table(
    TableName='Music',
    KeySchema=[
        {
            'AttributeName': 'Artist',
            'KeyType': 'HASH'
        },
        {
            'AttributeName': 'Song',
            'KeyType': 'RANGE'
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'Artist',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'Song',
            'AttributeType': 'S'
        },
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 5,
        'WriteCapacityUnits': 5
    }
)

# Wait until the table exists.
table.meta.client.get_waiter('table_exists').wait(TableName='Music')


#Once you have a DynamoDB.Table resource you can add new items to the table using DynamoDB.Table.put_item():

table.put_item(
   Item={
        'Artist': 'Pink Floyd',
        'Song': 'Money',
        'Album': 'The Dark Side of the Moon',
        'Year': 1973,
        }
)


# Print out some data about the table.
print(table.item_count)

response = table.get_item(
    Key={
        'Artist': 'Pink Floyd',
        'Song': 'Money'
    }
)
item = response['Item']
print(item)
