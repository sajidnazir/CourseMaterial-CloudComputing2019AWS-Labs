
#https://github.com/awsdocs/amazon-rekognition-developer-guide/blob/master/doc_source/images-s3.md

import boto3
import os


client = boto3.client('rekognition')

# Change bucket and photo to your S3 Bucket and image.
bucket='mybucket' 
photo='myphoto'                

response = client.detect_labels(Image={'S3Object':{'Bucket':bucket,'Name':photo}},
        MaxLabels=10) 

print('Detected labels for ' + photo) 
print(response)

print('*****************************')


for label in response['Labels']:
    print ("Label: " + label['Name'])
    print ("Confidence: " + str(label['Confidence']))
    print ("----------")
  


